package com.example.gps;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.widget.TextView;

public class MainActivity extends Activity {

	TextView t1;
	TextView t2;
	TextView t3;
	LocationManager lm;
	Criteria kr;
	Location loc;
	String najlepszyDostawca;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		t1=(TextView) findViewById(R.id.textView1);
		t2=(TextView) findViewById(R.id.textView2);
		t3=(TextView) findViewById(R.id.textView3);
		
		kr=new Criteria();
		lm=(LocationManager) getSystemService(LOCATION_SERVICE);		
		najlepszyDostawca=lm.getBestProvider(kr, true);			
		loc=lm.getLastKnownLocation(najlepszyDostawca);		
		t1.setText("najlepszy dostawca: "+najlepszyDostawca);
		t2.setText("długość geograficzna: "+loc.getLongitude());
		t3.setText("szerokość geograficzna: "+loc.getLatitude());
		
	}
}
